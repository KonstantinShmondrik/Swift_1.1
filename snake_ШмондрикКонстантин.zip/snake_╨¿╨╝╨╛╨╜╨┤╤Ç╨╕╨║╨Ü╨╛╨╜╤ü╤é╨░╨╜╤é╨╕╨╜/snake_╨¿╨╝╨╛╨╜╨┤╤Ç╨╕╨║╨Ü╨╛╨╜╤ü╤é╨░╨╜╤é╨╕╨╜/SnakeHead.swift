//
//  SnakeHead.swift
//  snake_ШмондрикКонстантин
//
//  Created by Константин Шмондрик on 16.10.2021.
//

import UIKit

class SnakeHead: SnakeBodyPart{
    override init(atPOint point: CGPoint){
        super.init(atPOint: point)
        self.physicsBody?.categoryBitMask = CollisonCategories.SnakeHead
        self.physicsBody?.contactTestBitMask = CollisonCategories.EdgeBody | CollisonCategories.Apple | CollisonCategories.Snake
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
        
    }
}

